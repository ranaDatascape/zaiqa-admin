import"./index-Cv0MCJep.js";/* empty css                      */const s=()=>({handleDisableForDemo:()=>!1});export{s as u};
