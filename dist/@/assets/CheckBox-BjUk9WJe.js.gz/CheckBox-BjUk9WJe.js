import{j as e}from"./index-Cv0MCJep.js";const c=({id:n,name:r,type:t,handleClick:o,isChecked:s})=>e.jsx(e.Fragment,{children:e.jsx("input",{id:n,name:r,type:t,onChange:o,checked:s})});export{c as C};
